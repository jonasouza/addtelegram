# Deploy Method

## 🚀 Heroku Deployment
###### Click the button below to deploy on Heroku!
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/rommelnita/Telegram-members-adder)

## 🚀 Okteto Deployment
###### Click the button below to deploy on Okteto!
[![Develop on Okteto](https://okteto.com/develop-okteto.svg)](https://cloud.okteto.com/deploy?repository=https://github.com/rommelnita/Telegram-members-adder&branch=main)

## 🚀 Railway Deployment
###### Click the button below to deploy on Railway!
[![Deploy+on+Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https://github.com/GodseXD/Telegram-members-adder&envs=API_ID,API_HASH,BOT_TOKEN)


## Credit


[VIP BOY ](https://github.com/The_Vip_Boy)
